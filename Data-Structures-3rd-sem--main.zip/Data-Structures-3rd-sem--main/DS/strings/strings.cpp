#include <iostream>
#include <cstring>
using namespace std;
int main()
{
    char str[] = {"hello world"};
    cout << "length is :"
         << strlen(str) << endl
         << str << endl;

    return 0;
}