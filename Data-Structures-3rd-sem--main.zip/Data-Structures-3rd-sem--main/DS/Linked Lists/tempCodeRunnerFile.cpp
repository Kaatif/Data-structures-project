
    circular1.deleteAtTail();